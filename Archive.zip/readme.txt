


jQuery Tweetie
- Simple Twitter Feed Plugin that works with new Twitter 1.1 API.
- https://github.com/sonnyt/Tweetie

jqueryIntroLoader (version 1.6.2)
- a jQuery plugin for generate animated Intro Loading Pages.
- https://github.com/Gix075/jqueryIntroLoader