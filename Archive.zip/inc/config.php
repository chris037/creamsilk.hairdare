<?php
/*
Config File
*/

// Valid constant names
define("YT_VIDEO", "https://www.youtube.com/embed/Wb8ePxP-0vk");
define("VIDEO_SHARE_TWEET", "I want Nadine Lustre to bring CreamSilkHairDare to <Insert Your School Name> https://youtu.be/Wb8ePxP-0vk");

define("ALBUM_DIR", "/repository/albums/");
define("BITLY_ACCESS_TOKEN", "5c40114efde3b52676b6ac5d80474e00851461f6");


?>