<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>The Brand New Web Site</title>
  <meta name="description" content="The Brand New Web Site">
  <meta name="author" content="Barattalo.it">
  <meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@site_username">
<meta name="twitter:title" content="Top 10 Things Ever">
<meta name="twitter:description" content="Up than 200 characters.">
<meta name="twitter:creator" content="@creator_username">
<meta name="twitter:image:src" content="https://randomuser.me/api/portraits/men/87.jpg">
<meta name="twitter:domain" content="YourDomain.com">
  <link rel="stylesheet" href="css/styles.css?v=1.0">
  <!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
</head>
<body>
 <img src="https://randomuser.me/api/portraits/men/87.jpg"/>
 
 
	<!-- run javascript at the end -->
  <script src="js/scripts.js"></script>
</body>
</html>